const express = require('express');
//const fileUpload = require('express-fileupload');
const cors = require('cors');
//const fs = require('fs');

const app = express();


// middle ware
//app.use(express.static('public')); //to access the files in public folder
app.use(cors()); // it enables all cors requests
//app.use(fileUpload());


// file upload api
app.post('/upload', (req, res) => {
    res.setHeader("Content-Type", "multipart/form-data");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,X-Amz-User-Agent");

    
    try{


        var event = req["content-type"];
        var context = req.apiGateway;


        //res.status(500).send({ msg: req.file });        
        
        if (!req.files) {
            return res.status(500).send({ msg: "log1: " + event +" | " + context})
        }
            // accessing the file
        const myFile = req.files;
        console.log(myFile);

        var buffer = myFile.data;
        var obj=buffer.toString('utf8');
        console.log(JSON.parse(obj));   

        return res.send(JSON.parse(obj)); 
    }catch(e){
        return res.status(500).send({ msg: "error1: "+e})
    }  
 
})

// file download api
app.post('/download', (req, res) => {

    var event = req.apiGateway.event;
    var context = req.apiGateway.context;

    if (!req.body.json) {
        return res.status(500).send({ msg: "body: "+req.body })
    }
    res.set({"Content-Disposition":"attachment; filename=\"current.json\""});

    res.setHeader('Access-Control-Allow-Origin', '*') // Request methods you wish to allow 
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE') // Request headers you wish to allow 
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type') // Set to true if you need the website to include cookies in the requests sent // to the API (e.g. in case you use sessions) 
    res.setHeader('Access-Control-Allow-Credentials', true) // Pass to next layer of middleware 


    res.send(JSON.stringify(req.body.json));  
    
})

module.exports = app

/* app.listen(4500, () => {
    console.log('server is running at port 4500');
}) */